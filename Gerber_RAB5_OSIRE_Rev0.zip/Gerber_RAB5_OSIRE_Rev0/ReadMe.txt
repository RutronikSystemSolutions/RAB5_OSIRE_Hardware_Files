
Project RAB5-OSIRE Rev0:
PCB dimensions 60.25x71.79mm.
2 Layers.
Thickness: 1.55mm FR4.
Mask color: WHITE.
Silkscreen color: BLACK.
Finish: Immersion Gold.